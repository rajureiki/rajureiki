# ESP8266WiFiControl
You can control 4 channel relay outputs via WiFi Network with ESP8266 WiFi Module.
Vist for Full detail
http://androidcontrol.blogspot.com/2016/05/esp8266-wifi-control-relay.html

Need Library Adafruit_GFX.h ( Version 1.0.2 only ) , ESP_Adafruit_SSD1306.h 

Developer amphancm@gmail.com ,digital2u.net@gmail.com http://softpowergroup.net/
